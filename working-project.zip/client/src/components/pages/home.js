import React from "react";

function Home(){
  console.log('Welcome Home');

  return (
    <header className="home-cta">
      <h1>
        Welcome to the adventure of a lifetime
        <br />
        <small>It is always a great day at Georgian</small>
      </h1>
    </header>
  );
}

export default Home;